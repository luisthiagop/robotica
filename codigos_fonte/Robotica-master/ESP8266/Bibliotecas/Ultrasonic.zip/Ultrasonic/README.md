Esta biblioteca foi criada para utilização d o sensor ultrassônico HC-SR04.

Possui temporização, conversão métrica (centímetro e polegada) e métodos de desvio padrão. 
Algumas ideias foram recolhidas de uma biblioteca criada pelo **ITead studio** em https://www.itead.cc/.

Veja os códigos e os exemplos para entender como a biblioteca funciona.

O código de desvio padrão pode ser removido da compilação, resultando em uma economia significativa de recursos. Para fazer isto basta comentar a linha.
```c++
#define COMPILE_STD_DEV
```
definição no arquivo de cabeçalho.


**mailto: //carl.nobile@gmail.com**
